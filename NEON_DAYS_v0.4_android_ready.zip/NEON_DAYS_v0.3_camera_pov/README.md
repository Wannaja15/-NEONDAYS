# NEON DAYS — Rebuild v0.2 Character Controls

Fondasi awal game simulasi kehidupan anime 3D menggunakan Godot 4.3+.

## Keputusan desain
- Dunia menengah berbasis distrik yang saling terhubung.
- Fokus cerita kehidupan sehari-hari (life simulation).
- Kamera dapat berganti third-person dekat / first-person bergaya POV Minecraft; kamera third-person dipusatkan di belakang karakter dengan sudut menunduk ringan.
- Multiplayer online menjadi target, dengan fondasi ENet untuk uji LAN.
- Prioritas awal: gameplay inti stabil sebelum konten besar ditambahkan.

## Kontrol desktop
- WASD / panah: bergerak relatif terhadap arah kamera
- Shift: berlari
- Space: lompat
- Klik kanan + gerakkan mouse: putar kamera
- V: ganti first-person / third-person
- Tombol INTERAKSI pada HUD: berbicara dengan NPC terdekat

## Kontrol Android
- Joystick kiri: gerak analog ke segala arah
- Geser area kanan atas: putar kamera
- Tombol LARI: tahan untuk berlari
- Tombol LOMPAT, KAMERA, dan INTERAKSI: aksi utama
- Posisi kontrol masih perlu diuji pada beberapa rasio layar dan perangkat Android.

## Update karakter v0.2
- Arah gerak sekarang dihitung dari yaw kamera dan sumbu maju sudah diperbaiki.
- Akselerasi, pengereman, dan kontrol udara dipisahkan agar gerak lebih halus.
- Kaki dan lengan memakai pivot sendi sehingga ayunan animasi tidak berputar dari tengah mesh.
- Animasi prosedural memiliki pose idle, jalan, lari, lompat, dan jatuh.
- Pergantian kamera first-person / third-person memakai transisi posisi dan FOV yang halus.
- First-person menyembunyikan torso dan kepala agar tidak menutupi pandangan.
- HUD Android memakai joystick analog dan area sentuh untuk melihat sekeliling.

## Isi versi ini
- Scene utama dan kota prototype dengan jalan, trotoar, bangunan, jendela, taman, dan pepohonan.
- Player CharacterBody3D, collision capsule, kontrol gerak, kamera first/third person.
- NPC interaktif dengan dialog sederhana.
- Siklus waktu dasar.
- HUD dan tombol sentuh.
- Save manager dasar.
- Fondasi ENet host/join untuk tahap multiplayer berikutnya.

## Batasan yang diketahui
- Model karakter masih placeholder procedural, belum memakai model anime rigged.
- Animasi masih prosedural pada pivot sederhana, belum menggunakan rig dan skeletal animation final.
- Dunia masih blockout, bukan kota final.
- Multiplayer manager belum disambungkan ke sistem spawn/sinkronisasi player; belum dapat disebut multiplayer siap dimainkan.
- Belum ada sistem quest lengkap, inventory, kendaraan, atau interior yang bisa dimasuki.
- Belum ada APK.
- Pemeriksaan source statis sudah dilakukan, tetapi proyek belum dijalankan di Godot dan belum dibuat build Android; runtime tetap belum terverifikasi.

## Membuka proyek
1. Instal Godot 4.3 atau lebih baru.
2. Buka Project Manager.
3. Pilih Import, lalu pilih folder ini atau file `project.godot`.
4. Jalankan `scenes/main/Main.tscn`.

## Tahap berikutnya
1. Validasi parse dan jalankan proyek pada Godot.
2. Perbaiki error runtime dan kontrol.
3. Bangun state machine animasi yang benar.
4. Implementasikan NPC schedule, dialog pilihan, quest, dan save integration.
5. Implementasikan multiplayer authority, lobby, spawn, dan replication.
6. Buat environment modular dan optimasi Android.


## Update kamera v0.3
- Kamera third-person dipendekkan dari 4,5 menjadi 2,8 unit agar karakter dan lingkungan terasa lebih dekat.
- Sudut kamera dibuat sedikit menunduk seperti perspektif third-person Minecraft.
- Titik first-person dinaikkan ke tinggi mata (1,62 unit) dan kamera diletakkan tepat di titik pandang.
- FOV disetel lebih natural: 70 untuk third-person dan 75 untuk first-person.
- Transisi kamera halus yang sudah ada tetap dipertahankan.
- Catatan: jarak kamera belum memakai collision boom; pengujian runtime Godot tetap diperlukan untuk memeriksa clipping pada dinding.
