extends Control

signal vector_changed(value: Vector2)

@export_range(0.0, 0.9, 0.01) var deadzone := 0.12

var _pointer_id := -1
var _knob_offset := Vector2.ZERO

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    focus_mode = Control.FOCUS_NONE
    custom_minimum_size = Vector2(164.0, 164.0)
    queue_redraw()

func _draw() -> void:
    var center := size * 0.5
    var radius := minf(size.x, size.y) * 0.38
    draw_circle(center, radius, Color(0.04, 0.08, 0.14, 0.42))
    draw_arc(center, radius, 0.0, TAU, 64, Color(0.58, 0.82, 1.0, 0.78), 3.0, true)
    draw_circle(center + _knob_offset, radius * 0.36, Color(0.28, 0.72, 0.94, 0.78))
    draw_arc(center + _knob_offset, radius * 0.36, 0.0, TAU, 48, Color(0.88, 0.96, 1.0, 0.9), 2.0, true)

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and _pointer_id == -1:
            _pointer_id = event.index
            _update_stick(_to_local(event.position))
            accept_event()
        elif not event.pressed and event.index == _pointer_id:
            _release_stick()
            accept_event()
    elif event is InputEventScreenDrag and event.index == _pointer_id:
        _update_stick(_to_local(event.position))
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed and _pointer_id == -1:
            _pointer_id = -2
            _update_stick(get_local_mouse_position())
            accept_event()
        elif not event.pressed and _pointer_id == -2:
            _release_stick()
            accept_event()
    elif event is InputEventMouseMotion and _pointer_id == -2:
        _update_stick(get_local_mouse_position())
        accept_event()

func _to_local(viewport_position: Vector2) -> Vector2:
    return get_global_transform_with_canvas().affine_inverse() * viewport_position

func _update_stick(local_position: Vector2) -> void:
    var radius := minf(size.x, size.y) * 0.38
    var offset := (local_position - size * 0.5).limit_length(radius)
    _knob_offset = offset
    var raw_vector := offset / maxf(radius, 1.0)
    var strength := raw_vector.length()
    var output := Vector2.ZERO
    if strength > deadzone:
        output = raw_vector.normalized() * clampf((strength - deadzone) / (1.0 - deadzone), 0.0, 1.0)
    vector_changed.emit(output)
    queue_redraw()

func _release_stick() -> void:
    _pointer_id = -1
    _knob_offset = Vector2.ZERO
    vector_changed.emit(Vector2.ZERO)
    queue_redraw()
