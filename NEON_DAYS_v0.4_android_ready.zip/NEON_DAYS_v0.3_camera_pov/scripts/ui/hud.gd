extends CanvasLayer

const TouchJoystick = preload("res://scripts/ui/touch_joystick.gd")
const TouchLookArea = preload("res://scripts/ui/touch_look_area.gd")

signal interact_requested
signal camera_toggle_requested
signal camera_look_requested(delta: Vector2)

var root: Control
var status_label: Label
var clock_label: Label
var dialogue_panel: PanelContainer
var dialogue_text: Label

func _ready() -> void:
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    status_label = Label.new()
    status_label.position = Vector2(24.0, 18.0)
    status_label.add_theme_font_size_override("font_size", 22)
    status_label.add_theme_color_override("font_color", Color(0.8, 0.94, 1.0))
    root.add_child(status_label)

    clock_label = Label.new()
    clock_label.position = Vector2(24.0, 50.0)
    clock_label.add_theme_font_size_override("font_size", 18)
    clock_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.65))
    root.add_child(clock_label)

    _make_touch_look_area()
    _make_button("INTERAKSI", Vector2(-190.0, -100.0), Vector2(160.0, 64.0), _on_interact)
    _make_button("KAMERA", Vector2(-190.0, -178.0), Vector2(160.0, 58.0), _on_camera)
    _make_button("LOMPAT", Vector2(-190.0, -256.0), Vector2(160.0, 58.0), _on_jump)

    dialogue_panel = PanelContainer.new()
    dialogue_panel.anchor_left = 0.18
    dialogue_panel.anchor_right = 0.82
    dialogue_panel.anchor_top = 0.72
    dialogue_panel.anchor_bottom = 0.94
    dialogue_panel.visible = false
    root.add_child(dialogue_panel)

    dialogue_text = Label.new()
    dialogue_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    dialogue_text.add_theme_font_size_override("font_size", 20)
    dialogue_text.add_theme_color_override("font_color", Color(0.95, 0.97, 1.0))
    dialogue_panel.add_child(dialogue_text)
    _make_move_pad()

func _make_touch_look_area() -> void:
    var look_area = TouchLookArea.new()
    look_area.anchor_left = 0.48
    look_area.anchor_right = 1.0
    look_area.anchor_top = 0.0
    look_area.anchor_bottom = 0.68
    root.add_child(look_area)
    look_area.look_delta.connect(_on_camera_look)

func _make_button(text_value: String, offset: Vector2, button_size: Vector2, callback: Callable) -> void:
    var button := Button.new()
    button.text = text_value
    button.size = button_size
    button.anchor_left = 1.0
    button.anchor_right = 1.0
    button.anchor_top = 1.0
    button.anchor_bottom = 1.0
    button.position = offset
    button.add_theme_font_size_override("font_size", 17)
    button.pressed.connect(callback)
    root.add_child(button)

func _make_move_pad() -> void:
    var joystick = TouchJoystick.new()
    joystick.anchor_left = 0.0
    joystick.anchor_right = 0.0
    joystick.anchor_top = 1.0
    joystick.anchor_bottom = 1.0
    joystick.position = Vector2(24.0, -190.0)
    joystick.size = Vector2(164.0, 164.0)
    root.add_child(joystick)
    joystick.vector_changed.connect(_on_joystick_changed)
    _make_hold_button("LARI", Vector2(194.0, -126.0), Vector2(78.0, 54.0), "sprint")

func _make_hold_button(caption: String, offset: Vector2, button_size: Vector2, action: String) -> void:
    var button := Button.new()
    button.text = caption
    button.size = button_size
    button.anchor_left = 0.0
    button.anchor_right = 0.0
    button.anchor_top = 1.0
    button.anchor_bottom = 1.0
    button.position = offset
    button.add_theme_font_size_override("font_size", 16)
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    root.add_child(button)

func _set_action_strength(action: String, strength: float) -> void:
    var value := clampf(strength, 0.0, 1.0)
    if value > 0.01:
        Input.action_press(action, value)
    else:
        Input.action_release(action)

func _on_joystick_changed(value: Vector2) -> void:
    _set_action_strength("move_left", maxf(-value.x, 0.0))
    _set_action_strength("move_right", maxf(value.x, 0.0))
    _set_action_strength("move_forward", maxf(-value.y, 0.0))
    _set_action_strength("move_back", maxf(value.y, 0.0))

func _on_camera_look(delta: Vector2) -> void:
    camera_look_requested.emit(delta)

func _on_interact() -> void:
    if dialogue_panel and dialogue_panel.visible:
        dialogue_panel.visible = false
        return
    interact_requested.emit()

func _on_camera() -> void:
    camera_toggle_requested.emit()

func _on_jump() -> void:
    Input.action_press("jump")
    await get_tree().create_timer(0.12).timeout
    Input.action_release("jump")

func show_dialogue(speaker: Variant, line: Variant) -> void:
    dialogue_text.text = str(speaker) + "\n" + str(line) + "\n\n(Tap INTERAKSI untuk menutup)"
    dialogue_panel.visible = true

func set_status(value: String) -> void:
    status_label.text = value

func set_clock(value: String) -> void:
    clock_label.text = "Waktu: " + value
