extends Control

signal look_delta(delta: Vector2)

var _pointer_id := -1

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    focus_mode = Control.FOCUS_NONE

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and _pointer_id == -1:
            _pointer_id = event.index
            accept_event()
        elif not event.pressed and event.index == _pointer_id:
            _pointer_id = -1
            accept_event()
    elif event is InputEventScreenDrag and event.index == _pointer_id:
        look_delta.emit(event.relative)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed and _pointer_id == -1:
            _pointer_id = -2
            accept_event()
        elif not event.pressed and _pointer_id == -2:
            _pointer_id = -1
            accept_event()
    elif event is InputEventMouseMotion and _pointer_id == -2:
        look_delta.emit(event.relative)
        accept_event()
