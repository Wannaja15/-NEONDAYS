extends Node
## Basic local save data. Expand with version migration before release.

const SAVE_PATH := "user://neon_days_save.json"

func save_game(data: Dictionary) -> bool:
    var payload := {
        "schema_version": 1,
        "saved_at_unix": Time.get_unix_time_from_system(),
        "data": data
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_error("Tidak dapat membuka file save.")
        return false
    file.store_string(JSON.stringify(payload, "\t"))
    return true

func load_game() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return {}
    var parsed = JSON.parse_string(file.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        return {}
    if int(parsed.get("schema_version", 0)) != 1:
        push_warning("Versi save tidak didukung.")
        return {}
    return parsed.get("data", {})
