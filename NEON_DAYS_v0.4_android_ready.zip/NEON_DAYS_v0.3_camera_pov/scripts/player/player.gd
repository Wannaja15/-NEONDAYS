extends CharacterBody3D

@export var walk_speed := 4.2
@export var run_speed := 7.0
@export var ground_acceleration := 18.0
@export var ground_deceleration := 22.0
@export var air_acceleration := 6.0
@export var jump_velocity := 5.2
@export var mouse_sensitivity := 0.003
@export var touch_sensitivity := 0.0035
@export var camera_transition_speed := 10.0
@export var third_person_camera_offset := Vector3(0.0, 0.15, 2.8)
@export var first_person_camera_offset := Vector3.ZERO

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var camera_yaw := 0.0
var camera_pitch := -0.22
var first_person := false
var visual_root: Node3D
var camera_pivot: Node3D
var camera: Camera3D
var body_mesh: MeshInstance3D
var head_mesh: MeshInstance3D
var hair_mesh: MeshInstance3D
var left_leg: Node3D
var right_leg: Node3D
var left_arm: Node3D
var right_arm: Node3D
var camera_target_offset := Vector3.ZERO
var camera_target_fov := 70.0
var anim_time := 0.0

func _ready() -> void:
    name = "Player"
    add_to_group("player")
    _create_collision()
    _create_visual()
    _create_camera()

func _physics_process(delta: float) -> void:
    if Input.is_action_just_pressed("camera_toggle"):
        toggle_camera_mode()

    var input_vector := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var camera_basis := camera_pivot.global_transform.basis
    var forward := -camera_basis.z
    forward.y = 0.0
    forward = forward.normalized()
    var right := camera_basis.x
    right.y = 0.0
    right = right.normalized()

    # Input.get_vector() returns negative Y for forward, so invert that axis here.
    var move_vector := right * input_vector.x - forward * input_vector.y
    var input_strength := clampf(move_vector.length(), 0.0, 1.0)
    var move_direction := move_vector.normalized() if input_strength > 0.001 else Vector3.ZERO
    var target_speed := run_speed if Input.is_action_pressed("sprint") else walk_speed
    var target_horizontal_velocity := move_direction * target_speed * input_strength
    var horizontal_velocity := Vector3(velocity.x, 0.0, velocity.z)

    if is_on_floor():
        var rate := ground_acceleration if input_strength > 0.01 else ground_deceleration
        horizontal_velocity = horizontal_velocity.move_toward(target_horizontal_velocity, rate * delta)
    else:
        horizontal_velocity = horizontal_velocity.move_toward(target_horizontal_velocity, air_acceleration * delta)

    velocity.x = horizontal_velocity.x
    velocity.z = horizontal_velocity.z

    if not is_on_floor():
        velocity.y -= gravity * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = jump_velocity

    if move_direction.length_squared() > 0.001 and horizontal_velocity.length() > 0.15:
        # Godot characters face local -Z; this keeps the visual facing the travel direction.
        var target_angle := atan2(-move_direction.x, -move_direction.z)
        visual_root.rotation.y = lerp_angle(visual_root.rotation.y, target_angle, 1.0 - exp(-12.0 * delta))

    move_and_slide()
    _update_animation(delta)

func _process(delta: float) -> void:
    if not camera:
        return
    var blend := 1.0 - exp(-camera_transition_speed * delta)
    camera.position = camera.position.lerp(camera_target_offset, blend)
    camera.fov = lerpf(camera.fov, camera_target_fov, blend)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _apply_look_delta(event.relative, mouse_sensitivity)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func apply_touch_look(delta: Vector2) -> void:
    _apply_look_delta(delta, touch_sensitivity)

func _apply_look_delta(delta: Vector2, sensitivity: float) -> void:
    camera_yaw = wrapf(camera_yaw - delta.x * sensitivity, -PI, PI)
    camera_pitch = clampf(camera_pitch - delta.y * sensitivity, -1.05, 0.65)
    camera_pivot.rotation = Vector3(camera_pitch, camera_yaw, 0.0)

func _create_collision() -> void:
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.8
    shape.shape = capsule
    shape.position.y = 0.9
    add_child(shape)

func _create_visual() -> void:
    visual_root = Node3D.new()
    add_child(visual_root)

    body_mesh = _make_capsule(Vector3(0.0, 0.92, 0.0), 0.34, 0.9, Color(0.18, 0.32, 0.68))
    visual_root.add_child(body_mesh)
    head_mesh = _make_sphere(Vector3(0.0, 1.68, 0.0), 0.27, Color(0.96, 0.76, 0.65))
    visual_root.add_child(head_mesh)
    hair_mesh = _make_sphere(Vector3(0.0, 1.82, -0.035), 0.285, Color(0.12, 0.1, 0.18))
    hair_mesh.scale = Vector3(1.0, 0.72, 1.0)
    visual_root.add_child(hair_mesh)

    for side in [-1, 1]:
        var leg_pivot := Node3D.new()
        leg_pivot.name = "Leg_" + str(side)
        leg_pivot.position = Vector3(side * 0.14, 0.66, 0.0)
        visual_root.add_child(leg_pivot)
        var leg_mesh := _make_capsule(Vector3(0.0, -0.31, 0.0), 0.105, 0.62, Color(0.12, 0.14, 0.2))
        leg_pivot.add_child(leg_mesh)
        if side < 0:
            left_leg = leg_pivot
        else:
            right_leg = leg_pivot

        var arm_pivot := Node3D.new()
        arm_pivot.name = "Arm_" + str(side)
        arm_pivot.position = Vector3(side * 0.39, 1.3, 0.0)
        arm_pivot.rotation.z = side * -0.12
        visual_root.add_child(arm_pivot)
        var arm_mesh := _make_capsule(Vector3(0.0, -0.31, 0.0), 0.095, 0.62, Color(0.96, 0.76, 0.65))
        arm_pivot.add_child(arm_mesh)
        if side < 0:
            left_arm = arm_pivot
        else:
            right_arm = arm_pivot

func _make_capsule(pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    var capsule_mesh := CapsuleMesh.new()
    capsule_mesh.radius = radius
    capsule_mesh.height = height
    instance.mesh = capsule_mesh
    instance.position = pos
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    instance.material_override = material
    return instance

func _make_sphere(pos: Vector3, radius: float, color: Color) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    var sphere_mesh := SphereMesh.new()
    sphere_mesh.radius = radius
    sphere_mesh.height = radius * 2.0
    instance.mesh = sphere_mesh
    instance.position = pos
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    instance.material_override = material
    return instance

func _create_camera() -> void:
    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0.0, 1.62, 0.0)
    add_child(camera_pivot)

    camera = Camera3D.new()
    camera.position = third_person_camera_offset
    camera.current = true
    camera.fov = 70.0
    camera_pivot.add_child(camera)
    camera_pivot.rotation = Vector3(camera_pitch, camera_yaw, 0.0)
    camera_target_offset = third_person_camera_offset
    camera_target_fov = 70.0

func _update_animation(delta: float) -> void:
    var horizontal_speed := Vector2(velocity.x, velocity.z).length()
    var grounded := is_on_floor()
    var moving := grounded and horizontal_speed > 0.2
    var running := moving and horizontal_speed > walk_speed * 1.12
    var run_blend := clampf((horizontal_speed - walk_speed * 0.75) / maxf(run_speed - walk_speed * 0.75, 0.01), 0.0, 1.0)
    anim_time += delta * (lerpf(5.5, 9.5, run_blend) if moving else 1.8)

    var left_leg_target := 0.0
    var right_leg_target := 0.0
    var left_arm_target := 0.0
    var right_arm_target := 0.0
    var bob_target := 0.0
    var head_target := 0.0

    if not grounded:
        if velocity.y > 0.0:
            left_leg_target = -0.38
            right_leg_target = 0.42
            left_arm_target = -0.72
            right_arm_target = -0.72
        else:
            left_leg_target = 0.12
            right_leg_target = -0.12
            left_arm_target = 0.58
            right_arm_target = 0.58
    elif moving:
        var stride := lerpf(0.34, 0.62, run_blend)
        var swing := sin(anim_time) * stride * clampf(horizontal_speed / maxf(run_speed, 0.01), 0.0, 1.0)
        left_leg_target = swing
        right_leg_target = -swing
        left_arm_target = -swing * 0.72
        right_arm_target = swing * 0.72
        bob_target = absf(sin(anim_time * 2.0)) * (0.025 if running else 0.015)
    else:
        left_arm_target = sin(anim_time * 0.7) * 0.025
        right_arm_target = -left_arm_target
        bob_target = sin(anim_time * 1.6) * 0.012
        head_target = sin(anim_time * 0.8) * 0.012

    var pose_blend := 1.0 - exp(-14.0 * delta)
    if left_leg:
        left_leg.rotation.x = lerpf(left_leg.rotation.x, left_leg_target, pose_blend)
    if right_leg:
        right_leg.rotation.x = lerpf(right_leg.rotation.x, right_leg_target, pose_blend)
    if left_arm:
        left_arm.rotation.x = lerpf(left_arm.rotation.x, left_arm_target, pose_blend)
    if right_arm:
        right_arm.rotation.x = lerpf(right_arm.rotation.x, right_arm_target, pose_blend)
    if head_mesh:
        head_mesh.rotation.x = lerpf(head_mesh.rotation.x, head_target, pose_blend)
    if visual_root:
        visual_root.position.y = lerpf(visual_root.position.y, bob_target, pose_blend)

func toggle_camera_mode() -> void:
    first_person = not first_person
    camera_target_offset = first_person_camera_offset if first_person else third_person_camera_offset
    camera_target_fov = 75.0 if first_person else 70.0
    if body_mesh:
        body_mesh.visible = not first_person
    if head_mesh:
        head_mesh.visible = not first_person
    if hair_mesh:
        hair_mesh.visible = not first_person
