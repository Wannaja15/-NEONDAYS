extends CharacterBody3D

@export var display_name := "Aiko"
@export_multiline var greeting := "Hai! Selamat datang di kota ini. Ada banyak tempat menarik untuk dikunjungi."
var idle_time := 0.0

func _ready() -> void:
    add_to_group("interactable")
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.35
    capsule.height = 1.8
    collision.shape = capsule
    collision.position.y = 0.9
    add_child(collision)
    var body := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.32
    mesh.height = 1.0
    body.mesh = mesh
    body.position.y = 0.9
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.72,0.25,0.48)
    body.material_override = mat
    add_child(body)
    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.26
    sphere.height = 0.52
    head.mesh = sphere
    head.position.y = 1.62
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.96,0.78,0.68)
    head.material_override = skin
    add_child(head)
    var label := Label3D.new()
    label.text = display_name
    label.position.y = 2.15
    label.font_size = 36
    label.modulate = Color(1,0.9,0.96)
    add_child(label)

func _process(delta: float) -> void:
    idle_time += delta
    position.y = 0.025 * sin(idle_time * 1.8)
