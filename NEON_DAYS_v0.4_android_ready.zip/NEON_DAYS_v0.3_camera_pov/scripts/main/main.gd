extends Node3D

const PlayerScene = preload("res://scenes/player/Player.tscn")
const NPCScene = preload("res://scenes/npc/NPC.tscn")
const HUDScene = preload("res://scenes/ui/HUD.tscn")

var player: CharacterBody3D
var hud: CanvasLayer
var day_clock := 8.0
var day_speed := 0.035

func _ready() -> void:
    _build_world()
    player = PlayerScene.instantiate()
    player.position = Vector3(0, 1.1, 4)
    add_child(player)
    var npc = NPCScene.instantiate()
    npc.position = Vector3(3, 0, -4)
    add_child(npc)
    hud = HUDScene.instantiate()
    add_child(hud)
    hud.interact_requested.connect(_on_interact)
    hud.camera_toggle_requested.connect(_on_camera_toggle)
    hud.camera_look_requested.connect(_on_camera_look)
    hud.call("set_status", "NEON DAYS • Hari 1")
    _apply_time_of_day()

func _process(delta: float) -> void:
    day_clock = fposmod(day_clock + delta * day_speed, 24.0)
    _apply_time_of_day()
    if hud:
        hud.call("set_clock", "%02d:%02d" % [int(day_clock), int((day_clock - int(day_clock)) * 60.0)])

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.035, 0.055, 0.09)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.48, 0.56, 0.72)
    environment.ambient_light_energy = 0.8
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.15
    add_child(sun)

    _add_box("Ground", Vector3(0, -0.35, 0), Vector3(90, 0.7, 90), Color(0.16, 0.2, 0.25), true)
    _add_box("MainRoad", Vector3(0, 0.02, 0), Vector3(12, 0.12, 90), Color(0.075, 0.09, 0.12), true)
    _add_box("SideRoad", Vector3(0, 0.03, -18), Vector3(90, 0.12, 10), Color(0.075, 0.09, 0.12), true)
    for z in range(-40, 45, 10):
        _add_box("RoadMark", Vector3(0, 0.1, z), Vector3(0.22, 0.025, 3.2), Color(0.9, 0.82, 0.55), false)
    for side in [-1, 1]:
        _add_box("Sidewalk", Vector3(side * 8.2, 0.15, 0), Vector3(4.2, 0.3, 90), Color(0.35, 0.38, 0.43), true)
        for i in range(4):
            var z := -30.0 + i * 20.0
            var h := 7.0 + float((i * 7) % 5)
            var col := [Color(0.24,0.3,0.42), Color(0.35,0.25,0.38), Color(0.2,0.38,0.43), Color(0.42,0.32,0.27)][i]
            _add_building(Vector3(side * (15.0 + (i % 2) * 5.0), h / 2.0, z), Vector3(9, h, 10), col)
    _add_box("ParkGrass", Vector3(23, 0.08, -18), Vector3(18, 0.16, 22), Color(0.13, 0.31, 0.23), true)
    for i in range(5):
        _add_tree(Vector3(17 + (i % 2) * 9, 0, -26 + i * 4))
    _add_sign(Vector3(-5.8, 3.2, -8), "NEON CAFE", Color(0.1, 0.8, 1.0))
    _add_sign(Vector3(5.8, 3.2, -25), "CITY LIFE", Color(1.0, 0.3, 0.65))

func _add_box(label: String, pos: Vector3, size: Vector3, color: Color, collision: bool) -> void:
    var body: Node3D
    if collision:
        body = StaticBody3D.new()
    else:
        body = Node3D.new()
    body.name = label
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.85
    mesh.material_override = mat
    body.add_child(mesh)
    if collision:
        var shape := CollisionShape3D.new()
        var box_shape := BoxShape3D.new()
        box_shape.size = size
        shape.shape = box_shape
        body.add_child(shape)
    add_child(body)

func _add_building(pos: Vector3, size: Vector3, color: Color) -> void:
    _add_box("Building", pos, size, color, true)
    for y in range(1, int(size.y / 2.0)):
        for x in [-1, 1]:
            var window_mat := Color(0.28, 0.72, 0.9) if (y + int(pos.z)) % 2 == 0 else Color(0.95, 0.63, 0.3)
            _add_box("Window", pos + Vector3(x * size.x * 0.28, -size.y * 0.5 + y * 1.7, -size.z * 0.505), Vector3(1.25, 0.85, 0.08), window_mat, false)

func _add_tree(pos: Vector3) -> void:
    _add_box("TreeTrunk", pos + Vector3(0, 1.0, 0), Vector3(0.45, 2, 0.45), Color(0.25,0.16,0.12), false)
    var crown := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 1.35
    sphere.height = 2.7
    crown.mesh = sphere
    crown.position = pos + Vector3(0, 2.8, 0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.42, 0.29)
    crown.material_override = mat
    add_child(crown)

func _add_sign(pos: Vector3, label: String, color: Color) -> void:
    var sign := Label3D.new()
    sign.text = label
    sign.position = pos
    sign.font_size = 64
    sign.modulate = color
    sign.outline_size = 10
    add_child(sign)

func _apply_time_of_day() -> void:
    var t := day_clock / 24.0
    var night := day_clock < 6.0 or day_clock > 18.0
    var bg := Color(0.025,0.04,0.09) if night else Color(0.38,0.62,0.82)
    var env_node := get_node_or_null("WorldEnvironment") as WorldEnvironment
    if env_node and env_node.environment:
        env_node.environment.background_color = bg
    var sun := get_node_or_null("Sun") as DirectionalLight3D
    if sun:
        sun.light_energy = 0.25 if night else 1.15
        sun.light_color = Color(0.48,0.55,0.85) if night else Color(1.0,0.88,0.72)

func _on_interact() -> void:
    var npc = get_tree().get_first_node_in_group("interactable")
    if npc and player and player.global_position.distance_to(npc.global_position) < 4.0:
        hud.call("show_dialogue", npc.get("display_name"), npc.get("greeting"))
    else:
        hud.call("show_dialogue", "NEON DAYS", "Belum ada orang di dekatmu. Jelajahi kota dan temukan aktivitas baru.")

func _on_camera_toggle() -> void:
    if player:
        player.toggle_camera_mode()

func _on_camera_look(delta: Vector2) -> void:
    if player and player.has_method("apply_touch_look"):
        player.apply_touch_look(delta)
