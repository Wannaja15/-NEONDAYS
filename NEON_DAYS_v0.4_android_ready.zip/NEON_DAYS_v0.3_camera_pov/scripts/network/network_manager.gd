extends Node
## Minimal ENet multiplayer foundation. Intended for trusted private sessions/LAN testing.
signal connection_status(message: String)

const DEFAULT_PORT := 24560
const MAX_CLIENTS := 8

func host_game(port: int = DEFAULT_PORT) -> Error:
    var peer := ENetMultiplayerPeer.new()
    var result := peer.create_server(port, MAX_CLIENTS)
    if result == OK:
        multiplayer.multiplayer_peer = peer
        connection_status.emit("Host aktif pada port %d" % port)
    else:
        connection_status.emit("Gagal membuat host: %s" % error_string(result))
    return result

func join_game(address: String, port: int = DEFAULT_PORT) -> Error:
    var peer := ENetMultiplayerPeer.new()
    var result := peer.create_client(address, port)
    if result == OK:
        multiplayer.multiplayer_peer = peer
        connection_status.emit("Menghubungkan ke %s..." % address)
    else:
        connection_status.emit("Gagal memulai koneksi: %s" % error_string(result))
    return result

func leave_game() -> void:
    multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    connection_status.emit("Keluar dari sesi multiplayer")
